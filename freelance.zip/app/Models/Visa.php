<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Visa extends Model
{
    use HasFactory;
    protected $fillable=[
        'center_apply',
        'date',
        'country',
        'travelers_number',
        'relation',
        'coupon',
        'total_price',
        'user_id'
    ];

    public function user(){
        return $this->belongsTo(User::class);
    }
}
