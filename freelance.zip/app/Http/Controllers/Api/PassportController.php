<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Resources\PassportResource;
use App\Models\Passport;
use App\Traits\GeneralTrait;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class PassportController extends Controller
{
    use GeneralTrait;
    public function addPassport(Request $request){
        $validator=Validator::make($request->all(),[
            'applicant_name'=>'required',
            'email'=>'required',
            'phone'=>'required',
            'country'=>'required',
            'passport_quantity'=>'required',
        ]);
        if($validator->fails()){
            return $this->returnError(400,$validator->messages());
        }else{
            $passport=Passport::create([
                'applicant_name'=>$request->applicant_name,
                'email'=>$request->email,
                'phone'=>$request->phone,
                'country'=>$request->country,
                'passport_quantity'=>$request->passport_quantity,
                'user_id'=>auth()->user()->id
            ]);
            return $this->returnData('data',$passport,'added successfully');
        }

    }


    public function passports(){
        $passport=Passport::all();
        return $this->returnData('data',PassportResource::collection($passport),'Done');

    }


    public function passportRequest(){
        $passport=Passport::where('user_id',auth()->user()->id)->get();
        return $this->returnData('data',PassportResource::collection($passport),'Done');
    }
}
