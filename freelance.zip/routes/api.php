<?php

use App\Http\Controllers\Api\PassportController;
use App\Http\Controllers\Api\RegistrationController;
use App\Http\Controllers\Api\VisaController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
    return $request->user();
});

Route::post('register',[RegistrationController::class,'register'])->name('register');
Route::post('login',[RegistrationController::class,'login'])->name('login');
Route::post('admin-login',[RegistrationController::class,'adminLogin']);


Route::group(['prefix' =>'auth','middleware' =>'auth:sanctum'], function () {

    Route::get('get-user',[VisaController::class,'getUser']);

    Route::post('add-visa',[VisaController::class,'addVisa']);
    Route::post('add-visa_information/{visa_id}',[VisaController::class,'addVisaInformation']);


    Route::post('add-passport',[PassportController::class,'addPassport']);

    // get requests section
    Route::get('user-visa-requests',[VisaController::class,'visaRequests']);
    Route::get('user-visa-information/{visa_id}',[VisaController::class,'visaInformation']);
    Route::get('user-passport',[PassportController::class,'passportRequest']);

});

Route::group(['prefix' =>'admin','middleware' =>'auth:sanctum'], function () {

    Route::get('get-visas',[VisaController::class,'visas']);
    Route::get('get-visa/{visa_information_id}',[VisaController::class,'visa']);

    Route::get('get-passports',[PassportController::class,'passports']);

});


